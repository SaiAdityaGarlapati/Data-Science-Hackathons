For Task A - shopalyst_problem_a.html
- both python and R have been used

For task B - shopalyst_problem_b.html
- R and Tableau have been used for Forecasting 
- public tableau link is present at end of shopalyst_problem_a.html